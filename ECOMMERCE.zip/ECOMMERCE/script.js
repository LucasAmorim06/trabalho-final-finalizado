// script.js

// Mensagem de boas-vindas
document.addEventListener("DOMContentLoaded", () => {
    const userName = prompt("Olá! Qual é o seu nome?");
    if (userName) {
      alert(`Bem-vindo ao nosso site, ${userName}! Aproveite os produtos que selecionamos para você.`);
    }
  });
  
  // Suavizar rolagem para a seção de produtos
  const explorarButton = document.querySelector(".button");
  explorarButton.addEventListener("click", (e) => {
    e.preventDefault();
    document.querySelector("#produtos").scrollIntoView({
      behavior: "smooth",
    });
  });
  
  // Feedback ao adicionar produto ao carrinho
  const forms = document.querySelectorAll(".produto form");
  forms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      e.preventDefault(); // Impede envio real, para demonstração
      const nomeProduto = form.querySelector('input[name="nome_produto"]').value;
      alert(`Você adicionou "${nomeProduto}" ao carrinho com sucesso!`);
    });
  });
  