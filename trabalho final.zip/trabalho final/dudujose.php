<?php

$host = 'localhost'; 
$dbname = 'contato'; 
$username = 'root'; 
$password = ''; 
 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
       
        $name = htmlspecialchars($_POST['name']);
        $email = htmlspecialchars($_POST['email']);
        $message = htmlspecialchars($_POST['message']);
 
        
        $stmt = $pdo->prepare("INSERT INTO contatos (name, email, message) VALUES (:name, :email, :message)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':message', $message);
        $stmt->execute();
 
       
        echo "Contato enviado com sucesso! Obrigado por entrar em contato.";
    }
} catch (PDOException $e) {
  
    echo "Erro ao salvar os dados: " . $e->getMessage();
}
?>
 