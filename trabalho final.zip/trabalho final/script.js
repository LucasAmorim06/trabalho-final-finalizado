document.getElementById('leadForm').addEventListener('submit', function (e) {
    e.preventDefault();
  
    // Coleta os dados do formulário
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
  
    // Simulação de envio (substitua pelo envio real para seu back-end)
    console.log('Dados enviados:', { name, email });
  
    // Mensagem de sucesso
    document.getElementById('formSuccess').style.display = 'block';
  
    // Limpa o formulário
    document.getElementById('leadForm').reset();
  });
  